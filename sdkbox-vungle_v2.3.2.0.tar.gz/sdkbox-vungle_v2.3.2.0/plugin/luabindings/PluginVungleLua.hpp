
#ifndef __PluginVungleLua_h__
#define __PluginVungleLua_h__

#ifdef __cplusplus
extern "C" {
#endif
#include "tolua++.h"
#ifdef __cplusplus
}
#endif

int register_all_PluginVungleLua(lua_State* tolua_S);







#endif // __PluginVungleLua_h__
