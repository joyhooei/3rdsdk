#ifndef __SDKBOX_ADS__
#define __SDKBOX_ADS__

// TODO move this file out of the core, and into its own submodule.
#include <string>

namespace sdkbox {
}

#endif